#ifndef CONSOLE_H
#define CONSOLE_H

bool check_console();
void alloc_console(nssm_service_t *);

#endif
